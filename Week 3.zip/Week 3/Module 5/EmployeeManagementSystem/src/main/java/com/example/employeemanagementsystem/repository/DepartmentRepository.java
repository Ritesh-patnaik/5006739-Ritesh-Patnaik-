package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.dto.EmployeeDTO;
import com.example.employeemanagementsystem.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.employeemanagementsystem.model.Employee;
import com.example.employeemanagementsystem.projections.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Find department by name
    Department findByName(String name);

    // Find departments by name containing a certain string
    List<Department> findByNameContaining(String nameFragment);

    @Query("SELECT e.id as id, e.name as name, e.email as email, e.department.name as departmentName FROM Employee e")
    List<EmployeeProjection> findAllProjectedBy();

    @Query("SELECT new com.example.employeemanagementsystem.dto.EmployeeDTO(e.id, e.name, e.email, e.department.name) FROM Employee e")
    List<EmployeeDTO> findAllEmployeeDTOs();
}
