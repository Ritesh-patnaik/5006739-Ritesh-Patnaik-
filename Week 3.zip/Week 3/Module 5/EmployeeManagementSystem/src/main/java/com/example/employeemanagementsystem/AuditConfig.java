package com.example.employeemanagementsystem;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;

@Configuration
@EnableJpaAuditing
public class AuditConfig {
    // This class enables JPA Auditing

    @Bean
    public AuditorAware<String> auditorAware() {
        return new com.example.employeemanagementsystem.config.AuditorAwareImpl();
    }
}
