package com.example.employeemanagementsystem.projections;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
    String getDepartmentName();  // Custom field combining data from related entities
}
