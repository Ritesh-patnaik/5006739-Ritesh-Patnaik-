package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.Sort;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find employees by name
    List<Employee> findByName(String name);

    // Find employees by department name
    List<Employee> findByDepartmentName(String departmentName);

    // Find employees by email containing a certain string
    List<Employee> findByEmailContaining(String emailFragment);

    // Find employees by name starting with a certain prefix
    List<Employee> findByNameStartingWith(String prefix);







    // Custom JPQL query to find employees by department name
    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);

    // Custom native SQL query to find employees by name and department
    @Query(value = "SELECT * FROM employees e INNER JOIN departments d ON e.department_id = d.id WHERE e.name = :name AND d.name = :departmentName", nativeQuery = true)
    List<Employee> findEmployeesByNameAndDepartment(@Param("name") String name, @Param("departmentName") String departmentName);

    Page<Employee> findAll(Pageable pageable);

    List<Employee> findAll(Sort sort);
}
