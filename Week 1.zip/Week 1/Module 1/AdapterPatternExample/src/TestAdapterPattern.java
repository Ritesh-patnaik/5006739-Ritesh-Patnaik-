public class TestAdapterPattern {
    public static void main(String[] args) {

        GooglePay googlePay = new GooglePay();
        PhonePe phonePe = new PhonePe();

        PaymentProcessor googlePayAdapter = new GooglePayAdapter(googlePay);
        PaymentProcessor phonePeAdapter = new PhonePeAdapter(phonePe);

        googlePayAdapter.processPayment(117);
        phonePeAdapter.processPayment(12345);
    }
}
