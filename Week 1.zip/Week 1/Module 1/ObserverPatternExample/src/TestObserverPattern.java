public class TestObserverPattern {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp1 = new MobileApp("MobileApp1");
        Observer mobileApp2 = new MobileApp("MobileApp2");
        Observer webApp = new WebApp("WebApp");

        stockMarket.register(mobileApp1);
        stockMarket.register(mobileApp2);
        stockMarket.register(webApp);
    
        System.out.println("Setting stock price to Rs100.00");
        stockMarket.setStockPrice(100.00);

        System.out.println("\nSetting stock price to Rs150.00");
        stockMarket.setStockPrice(150.00);

        stockMarket.deregister(mobileApp1);

        System.out.println("\nSetting stock price to Rs200.00");
        stockMarket.setStockPrice(200.00);
    }
}
