import java.util.Arrays;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size] = employee;
            size++;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public boolean deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                // Shift elements to the left to fill the gap
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null; // Nullify the last element
                size--;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        Employee emp1 = new Employee("1", "Naman", "Manager", 50000);
        Employee emp2 = new Employee("2", "Abinash", "Developer", 45000);
        Employee emp3 = new Employee("3", "Himanshu", "Designer", 50000);

        system.addEmployee(emp1);
        system.addEmployee(emp2);
        system.addEmployee(emp3);

        System.out.println("Traversing employees:");
        system.traverseEmployees();

        System.out.println("\nSearching for employee with ID 2:");
        Employee searchResult = system.searchEmployee("2");
        System.out.println(searchResult != null ? searchResult : "Employee not found");

        System.out.println("\nDeleting employee with ID 2:");
        boolean deleteResult = system.deleteEmployee("2");
        System.out.println(deleteResult ? "Employee deleted" : "Employee not found");

        System.out.println("\nTraversing employees after deletion:");
        system.traverseEmployees();
    }
}
