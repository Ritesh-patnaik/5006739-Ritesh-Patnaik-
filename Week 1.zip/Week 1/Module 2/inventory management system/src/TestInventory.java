public class TestInventory {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product product1 = new Product("1", "Laptop", 10, 100000);
        Product product2 = new Product("2", "Smartphone", 20, 12000);
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        Product updatedProduct1 = new Product("1", "Gaming Laptop", 5, 150000);
        inventory.updateProduct(updatedProduct1);

        Product product = inventory.getProduct("1");
        System.out.println("Retrieved product: " + product);

        inventory.deleteProduct("2");
    }
}
