import java.util.Arrays;

public class TestSort {
    public static void main(String[] args) {
        Order[] orders = {
                new Order("1", "A", 100),
                new Order("2", "B", 500),
                new Order("3", "C", 30),
                new Order("4", "D", 4000),
                new Order("5", "E", 500)
        };

        // Bubble Sort Test
        System.out.println("Bubble Sort:");
        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        BubbleSort.bubbleSort(bubbleSortedOrders);
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        // Quick Sort Test
        System.out.println("\nQuick Sort:");
        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
