public class TaskManagementSystem {
    private Node head;

    public TaskManagementSystem() {
        head = null;
    }

    public void addTask(Task task) {
        Node newNode = new Node(task);
        newNode.next = head;
        head = newNode;
    }

    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    public boolean deleteTask(String taskId) {
        if (head == null) {
            return false;
        }
        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;
            return true;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.task.getTaskId().equals(taskId)) {
                current.next = current.next.next;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();

        Task task1 = new Task("1", "Task 1", "Pending");
        Task task2 = new Task("2", "Task 2", "In Progress");
        Task task3 = new Task("3", "Task 3", "Completed");

        system.addTask(task1);
        system.addTask(task2);
        system.addTask(task3);

        System.out.println("Traversing tasks:");
        system.traverseTasks();

        System.out.println("\nSearching for task with ID 2:");
        Task searchResult = system.searchTask("2");
        System.out.println(searchResult != null ? searchResult : "Task not found");

        System.out.println("\nDeleting task with ID 2:");
        boolean deleteResult = system.deleteTask("2");
        System.out.println(deleteResult ? "Task deleted" : "Task not found");

        System.out.println("\nTraversing tasks after deletion:");
        system.traverseTasks();
    }
}
