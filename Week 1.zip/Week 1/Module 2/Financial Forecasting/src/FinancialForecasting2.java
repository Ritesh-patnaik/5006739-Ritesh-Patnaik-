public class        FinancialForecasting2 {

    public static double calculateFutureValueIterative(double presentValue, double growthRate, int years) {
        double futureValue = presentValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5%
        int years = 10;

        double futureValue = calculateFutureValueIterative(presentValue, growthRate, years);
        System.out.printf("The future value of the investment is: %.2f%n", futureValue);
    }
}
