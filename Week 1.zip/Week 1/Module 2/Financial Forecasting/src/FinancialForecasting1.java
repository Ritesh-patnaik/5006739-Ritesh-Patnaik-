import java.util.HashMap;
import java.util.Map;

public class FinancialForecasting1 {

    private static Map<Integer, Double> memo = new HashMap<>();

    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
        // Base case: no more years left to calculate
        if (years == 0) {
            return presentValue;
        }

        // Check if the value has already been computed
        if (memo.containsKey(years)) {
            return memo.get(years);
        }

        // Recursive case: calculate for one year and reduce the problem size
        double futureValue = calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
        memo.put(years, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5%
        int years = 10;

        double futureValue = calculateFutureValue(presentValue, growthRate, years);
        System.out.printf("The future value of the investment is: %.2f%n", futureValue);
    }
}
