public class FinancialForecasting {
    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
        // Base case: no more years left to calculate
        if (years == 0) {
            return presentValue;
        }

        // Recursive case: calculate for one year and reduce the problem size
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5%
        int years = 10;

        double futureValue = calculateFutureValue(presentValue, growthRate, years);
        System.out.printf("The future value of the investment is: %.2f%n", futureValue);
    }
}
