import java.util.ArrayList;
import java.util.List;

public class LibraryManagementSystem {

    private List<Book> books;

    public LibraryManagementSystem(List<Book> books) {
        this.books = books;
    }

    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public static void main(String[] args) {
        List<Book> bookList = new ArrayList<>();
        LibraryManagementSystem1 library = new LibraryManagementSystem1(bookList);

        Book book1 = new Book("1", "The Great Gatsby", "F. Scott Fitzgerald");
        Book book2 = new Book("2", "Moby Dick", "Herman Melville");
        Book book3 = new Book("3", "To Kill a Mockingbird", "Harper Lee");

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);

        System.out.println("Searching for 'Moby Dick' using linear search:");
        Book foundBook = library.linearSearchByTitle("Moby Dick");
        System.out.println(foundBook != null ? foundBook : "Book not found");
    }
}
