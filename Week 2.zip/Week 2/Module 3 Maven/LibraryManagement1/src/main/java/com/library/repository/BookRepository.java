package com.library.repository;

public class BookRepository {

    public void performRepositoryOperation() {
        // Repository logic here
        System.out.println("Repository operation is being performed.");
    }
}
