package com.example.bookstoreapi.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.ArrayList;
import com.example.bookstoreapi.model.Book;

@RestController
@RequestMapping("/books")
public class BookController {
    private List<Book> books = new ArrayList<>();

    // Define request mappings and methods here
}
